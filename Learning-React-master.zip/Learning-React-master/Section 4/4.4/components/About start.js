import React from 'react'

const About = () => {
    return (
        <h2>About page</h2>
    )
}

export default About