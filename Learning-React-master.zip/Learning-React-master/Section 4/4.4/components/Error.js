import React from 'react'

const Error = () => {
    return (
        <h2>Error page</h2>
    )
}

export default Error